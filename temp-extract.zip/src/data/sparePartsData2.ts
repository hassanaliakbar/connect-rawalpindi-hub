import { SparePart } from './sparePartsData';

export const additionalParts: SparePart[] = [
  {
    id: "7",
    name: "Precision Spray Nozzle",
    category: "Nozzles",
    brand: "DJI Agras",
    price: 8500,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863942605_733b4079.webp",
    compatibility: ["DJI Agras T30", "DJI Agras T20"],
    inStock: true
  },
  {
    id: "8",
    name: "Anti-Drift Spray Nozzle",
    category: "Nozzles",
    brand: "XAG",
    price: 7800,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863944463_cd1d616a.webp",
    compatibility: ["XAG P30", "XAG P40"],
    inStock: true
  },
  {
    id: "9",
    name: "Universal Spray Nozzle Set",
    category: "Nozzles",
    brand: "Universal",
    price: 6500,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863946176_229a3a87.webp",
    compatibility: ["Multiple Brands"],
    inStock: true
  },
  {
    id: "10",
    name: "Brushless Motor 6010",
    category: "Motors",
    brand: "DJI Agras",
    price: 28000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863946906_71b5eccf.webp",
    compatibility: ["DJI Agras T30"],
    inStock: true
  },
  {
    id: "11",
    name: "High Torque Motor",
    category: "Motors",
    brand: "XAG",
    price: 26500,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863948624_cf24d92c.webp",
    compatibility: ["XAG P40"],
    inStock: true
  },
  {
    id: "12",
    name: "Heavy Lift Motor",
    category: "Motors",
    brand: "Universal",
    price: 24000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863950311_8ced061d.webp",
    compatibility: ["Multiple Brands"],
    inStock: false
  }
];

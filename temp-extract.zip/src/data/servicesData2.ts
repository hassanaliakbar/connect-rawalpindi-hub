import { ServicePackage } from './servicesData';

export const additionalServices: ServicePackage[] = [
  {
    id: "4",
    name: "Weed Control Spray",
    nameUrdu: "جڑی بوٹیوں کا کنٹرول",
    description: "Targeted herbicide application for weed management",
    pricePerAcre: 850,
    features: ["Selective Herbicides", "Spot Treatment", "Crop Safety Guaranteed", "Follow-up Visit"],
    cropTypes: ["Rice", "Cotton", "Sugarcane"],
    coverage: "Punjab, Sindh"
  },
  {
    id: "5",
    name: "Disease Prevention Package",
    nameUrdu: "بیماری سے بچاؤ",
    description: "Fungicide and disease control spraying",
    pricePerAcre: 1100,
    features: ["Fungicide Application", "Disease Monitoring", "Expert Consultation", "Preventive Care"],
    cropTypes: ["All Crops"],
    coverage: "All Regions"
  },
  {
    id: "6",
    name: "Complete Farm Care",
    nameUrdu: "مکمل فارم کی دیکھ بھال",
    description: "Comprehensive season-long protection package",
    pricePerAcre: 3500,
    features: ["4 Spray Sessions", "Soil Testing", "Crop Monitoring", "24/7 Support", "Yield Guarantee"],
    cropTypes: ["All Major Crops"],
    coverage: "All Pakistan",
    popular: true
  }
];

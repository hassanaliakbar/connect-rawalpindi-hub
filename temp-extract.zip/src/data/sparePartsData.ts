export interface SparePart {
  id: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  image: string;
  compatibility: string[];
  inStock: boolean;
}

export const spareParts: SparePart[] = [
  {
    id: "1",
    name: "Carbon Fiber Propeller Set",
    category: "Propellers",
    brand: "DJI Agras",
    price: 12500,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863933919_2870941e.webp",
    compatibility: ["DJI Agras T30", "DJI Agras T20"],
    inStock: true
  },
  {
    id: "2",
    name: "High-Performance Propeller",
    category: "Propellers",
    brand: "XAG",
    price: 11000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863935783_8c7091e6.webp",
    compatibility: ["XAG P30", "XAG P40"],
    inStock: true
  },
  {
    id: "3",
    name: "Heavy Duty Propeller Blades",
    category: "Propellers",
    brand: "Universal",
    price: 9500,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863937657_86177f58.webp",
    compatibility: ["Multiple Brands"],
    inStock: true
  },
  {
    id: "4",
    name: "30000mAh LiPo Battery",
    category: "Batteries",
    brand: "DJI Agras",
    price: 85000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863938364_b100ca96.webp",
    compatibility: ["DJI Agras T30", "DJI Agras T40"],
    inStock: true
  },
  {
    id: "5",
    name: "Smart Battery 26000mAh",
    category: "Batteries",
    brand: "XAG",
    price: 75000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863940102_d36a115a.webp",
    compatibility: ["XAG P30", "XAG P40"],
    inStock: true
  },
  {
    id: "6",
    name: "Extended Flight Battery",
    category: "Batteries",
    brand: "Universal",
    price: 68000,
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863941845_3b6c25b4.webp",
    compatibility: ["Multiple Brands"],
    inStock: false
  }
];

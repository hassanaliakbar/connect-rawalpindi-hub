import React from 'react';
import { ServicePackage } from '../data/servicesData';

interface ServiceCardProps {
  service: ServicePackage;
  onRequestQuote: (service: ServicePackage) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service, onRequestQuote }) => {
  return (
    <div className={`bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 ${service.popular ? 'ring-4 ring-orange-500' : ''}`}>
      {service.popular && (
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-center py-2 font-bold">
          MOST POPULAR
        </div>
      )}
      <div className="p-6">
        <h3 className="text-2xl font-bold text-green-800 mb-2">{service.name}</h3>
        <p className="text-lg text-gray-600 mb-1 font-urdu">{service.nameUrdu}</p>
        <p className="text-gray-700 mb-4">{service.description}</p>
        
        <div className="mb-4">
          <span className="text-4xl font-bold text-orange-600">Rs {service.pricePerAcre}</span>
          <span className="text-gray-600">/acre</span>
        </div>

        <div className="mb-4">
          <h4 className="font-semibold text-gray-800 mb-2">Features:</h4>
          <ul className="space-y-1">
            {service.features.map((feature, idx) => (
              <li key={idx} className="flex items-center text-sm text-gray-700">
                <span className="text-green-600 mr-2">✓</span>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600"><strong>Crops:</strong> {service.cropTypes.join(', ')}</p>
          <p className="text-sm text-gray-600"><strong>Coverage:</strong> {service.coverage}</p>
        </div>

        <button
          onClick={() => onRequestQuote(service)}
          className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-3 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition-all"
        >
          Request Quote
        </button>
      </div>
    </div>
  );
};

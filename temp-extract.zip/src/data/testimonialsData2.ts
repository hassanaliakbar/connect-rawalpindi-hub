import { Testimonial } from './testimonialsData';

export const additionalTestimonials: Testimonial[] = [
  {
    id: "3",
    name: "Rashid Ali",
    nameUrdu: "راشد علی",
    location: "Sahiwal, Punjab",
    cropType: "Rice",
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863963378_f3ef5c26.webp",
    testimonial: "Fast service, excellent results. Highly recommend for rice farmers.",
    testimonialUrdu: "تیز رفتار خدمت، بہترین نتائج۔ چاول کے کسانوں کے لیے انتہائی تجویز کردہ۔",
    yieldIncrease: "35%",
    farmSize: "50 Acres"
  }
];

import React from 'react';
import { SparePart } from '../data/sparePartsData';

interface PartCardProps {
  part: SparePart;
  onRequestQuote: (part: SparePart) => void;
}

export const PartCard: React.FC<PartCardProps> = ({ part, onRequestQuote }) => {
  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
      <div className="relative">
        <img src={part.image} alt={part.name} className="w-full h-48 object-cover bg-gray-50" />
        {!part.inStock && (
          <div className="absolute top-2 right-2 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
            Out of Stock
          </div>
        )}
        {part.inStock && (
          <div className="absolute top-2 right-2 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
            In Stock
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="mb-2">
          <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">{part.brand}</span>
          <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 rounded ml-2">{part.category}</span>
        </div>
        
        <h3 className="text-lg font-bold text-gray-800 mb-2">{part.name}</h3>
        
        <div className="mb-3">
          <p className="text-xs text-gray-600 mb-1">Compatible with:</p>
          <p className="text-xs text-gray-700">{part.compatibility.join(', ')}</p>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-orange-600">Rs {part.price.toLocaleString()}</span>
          <button
            onClick={() => onRequestQuote(part)}
            disabled={!part.inStock}
            className={`px-4 py-2 rounded-lg font-semibold transition-all ${
              part.inStock
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {part.inStock ? 'Get Quote' : 'Unavailable'}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemName: string;
  itemType: 'service' | 'part';
}

export const QuoteModal: React.FC<QuoteModalProps> = ({ isOpen, onClose, itemName, itemType }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    location: '',
    acres: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
      setFormData({ name: '', phone: '', location: '', acres: '', message: '' });
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl">×</button>
        
        <h2 className="text-2xl font-bold text-green-800 mb-4">Request Quote</h2>
        <p className="text-gray-600 mb-4">For: <strong>{itemName}</strong></p>
        
        {submitted ? (
          <div className="text-center py-8">
            <div className="text-green-600 text-5xl mb-4">✓</div>
            <p className="text-xl font-semibold text-gray-800">Quote Request Sent!</p>
            <p className="text-gray-600">We'll contact you soon.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Your Name" required
              className="w-full mb-3 px-4 py-2 border rounded-lg"
              value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
            <input type="tel" placeholder="Phone Number" required
              className="w-full mb-3 px-4 py-2 border rounded-lg"
              value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} />
            <input type="text" placeholder="Location/District" required
              className="w-full mb-3 px-4 py-2 border rounded-lg"
              value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} />
            {itemType === 'service' && (
              <input type="number" placeholder="Farm Size (Acres)" required
                className="w-full mb-3 px-4 py-2 border rounded-lg"
                value={formData.acres} onChange={(e) => setFormData({...formData, acres: e.target.value})} />
            )}
            <textarea placeholder="Additional Details" rows={3}
              className="w-full mb-4 px-4 py-2 border rounded-lg"
              value={formData.message} onChange={(e) => setFormData({...formData, message: e.target.value})} />
            <button type="submit" className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700">
              Submit Request
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

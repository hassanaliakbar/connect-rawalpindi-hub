import React from 'react';
import { Testimonial } from '../data/testimonialsData';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <div className="flex items-start mb-4">
        <img 
          src={testimonial.image} 
          alt={testimonial.name} 
          className="w-20 h-20 rounded-full object-cover mr-4 border-4 border-green-200"
        />
        <div>
          <h4 className="text-xl font-bold text-gray-800">{testimonial.name}</h4>
          <p className="text-sm text-gray-600 font-urdu">{testimonial.nameUrdu}</p>
          <p className="text-sm text-gray-600">{testimonial.location}</p>
        </div>
      </div>
      
      <div className="mb-4">
        <p className="text-gray-700 italic mb-2">"{testimonial.testimonial}"</p>
        <p className="text-gray-600 text-sm font-urdu">"{testimonial.testimonialUrdu}"</p>
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        <div>
          <p className="text-xs text-gray-600">Crop Type</p>
          <p className="text-sm font-semibold text-green-700">{testimonial.cropType}</p>
        </div>
        <div>
          <p className="text-xs text-gray-600">Farm Size</p>
          <p className="text-sm font-semibold text-blue-700">{testimonial.farmSize}</p>
        </div>
        <div>
          <p className="text-xs text-gray-600">Yield Increase</p>
          <p className="text-2xl font-bold text-orange-600">{testimonial.yieldIncrease}</p>
        </div>
      </div>
    </div>
  );
};

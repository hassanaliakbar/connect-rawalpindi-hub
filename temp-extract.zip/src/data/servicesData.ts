export interface ServicePackage {
  id: string;
  name: string;
  nameUrdu: string;
  description: string;
  pricePerAcre: number;
  features: string[];
  cropTypes: string[];
  coverage: string;
  popular?: boolean;
}

export const servicePackages: ServicePackage[] = [
  {
    id: "1",
    name: "Basic Spray Package",
    nameUrdu: "بنیادی سپرے پیکیج",
    description: "Essential crop protection for small to medium farms",
    pricePerAcre: 800,
    features: ["Pesticide Application", "Basic Coverage", "Single Pass", "Standard Nozzles"],
    cropTypes: ["Wheat", "Rice", "Cotton"],
    coverage: "All Punjab Districts"
  },
  {
    id: "2",
    name: "Premium Spray Package",
    nameUrdu: "پریمیم سپرے پیکیج",
    description: "Advanced precision spraying with GPS mapping",
    pricePerAcre: 1200,
    features: ["Precision GPS Mapping", "Dual Pass Coverage", "Anti-Drift Technology", "Real-time Monitoring"],
    cropTypes: ["All Major Crops"],
    coverage: "Punjab, Sindh, KPK",
    popular: true
  },
  {
    id: "3",
    name: "Fertilizer Application",
    nameUrdu: "کھاد کی درخواست",
    description: "Liquid fertilizer spray for optimal growth",
    pricePerAcre: 950,
    features: ["Liquid Fertilizer", "Uniform Distribution", "Soil Analysis Report", "Growth Tracking"],
    cropTypes: ["Wheat", "Sugarcane", "Maize"],
    coverage: "All Punjab Districts"
  }
];

import React, { useState } from 'react';
import { ServiceCard } from './ServiceCard';
import { PartCard } from './PartCard';
import { TestimonialCard } from './TestimonialCard';
import { QuoteModal } from './QuoteModal';
import { servicePackages } from '../data/servicesData';
import { additionalServices } from '../data/servicesData2';
import { spareParts } from '../data/sparePartsData';
import { additionalParts } from '../data/sparePartsData2';
import { testimonials } from '../data/testimonialsData';
import { additionalTestimonials } from '../data/testimonialsData2';
import { SparePart } from '../data/sparePartsData';
import { ServicePackage } from '../data/servicesData';

export default function AppLayout() {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState({ name: '', type: 'service' as 'service' | 'part' });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const allServices = [...servicePackages, ...additionalServices];
  const allParts = [...spareParts, ...additionalParts];
  const allTestimonials = [...testimonials, ...additionalTestimonials];

  const handleServiceQuote = (service: ServicePackage) => {
    setSelectedItem({ name: service.name, type: 'service' });
    setModalOpen(true);
  };

  const handlePartQuote = (part: SparePart) => {
    setSelectedItem({ name: part.name, type: 'part' });
    setModalOpen(true);
  };

  const filteredParts = allParts.filter(part => {
    const matchesSearch = part.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = selectedBrand === 'All' || part.brand === selectedBrand;
    const matchesCategory = selectedCategory === 'All' || part.category === selectedCategory;
    return matchesSearch && matchesBrand && matchesCategory;
  });

  const brands = ['All', ...Array.from(new Set(allParts.map(p => p.brand)))];
  const categories = ['All', ...Array.from(new Set(allParts.map(p => p.category)))];

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/923001234567?text=Hello, I need information about drone services', '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-gradient-to-r from-green-800 to-green-700 text-white sticky top-0 z-40 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">AgroSky Drones</h1>
              <p className="text-sm text-green-100">ایگرو اسکائی ڈرونز</p>
            </div>
            <div className="hidden md:flex space-x-6">
              <button onClick={() => scrollToSection('services')} className="hover:text-orange-300 transition">Services</button>
              <button onClick={() => scrollToSection('parts')} className="hover:text-orange-300 transition">Spare Parts</button>
              <button onClick={() => scrollToSection('testimonials')} className="hover:text-orange-300 transition">Success Stories</button>
              <button onClick={() => scrollToSection('contact')} className="hover:text-orange-300 transition">Contact</button>
            </div>
            <button onClick={openWhatsApp} className="bg-orange-500 px-6 py-2 rounded-lg font-semibold hover:bg-orange-600 transition">
              WhatsApp Us
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center text-white">
        <div className="absolute inset-0">
          <img 
            src="https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863932648_293ac68c.webp" 
            alt="Drone Agriculture" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50"></div>
        </div>
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-4">Precision Agriculture for Pakistan</h2>
          <p className="text-3xl mb-2 font-urdu">پاکستان کے لیے درست زراعت</p>
          <p className="text-xl mb-8 max-w-2xl mx-auto">Advanced drone spraying services and genuine spare parts for all major brands</p>
          <div className="flex gap-4 justify-center">
            <button onClick={() => scrollToSection('services')} className="bg-orange-500 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-600 transition">
              View Services
            </button>
            <button onClick={() => scrollToSection('parts')} className="bg-white text-green-800 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition">
              Browse Parts
            </button>
          </div>
        </div>
      </section>


      <QuoteModal isOpen={modalOpen} onClose={() => setModalOpen(false)} itemName={selectedItem.name} itemType={selectedItem.type} />
      
      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-green-700 to-green-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold mb-2">500+</div>
              <div className="text-green-100">Farms Served</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">15,000+</div>
              <div className="text-green-100">Acres Sprayed</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">30%</div>
              <div className="text-green-100">Avg Yield Increase</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">24/7</div>
              <div className="text-green-100">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Our Spray Services</h2>
            <p className="text-2xl text-gray-600 font-urdu">ہماری سپرے خدمات</p>
            <p className="text-gray-600 mt-2">Professional drone spraying for all major crops across Pakistan</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {allServices.map(service => (
              <ServiceCard key={service.id} service={service} onRequestQuote={handleServiceQuote} />
            ))}
          </div>
        </div>
      </section>

      {/* Spare Parts Section */}
      <section id="parts" className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Genuine Spare Parts</h2>
            <p className="text-2xl text-gray-600 font-urdu">اصلی اسپیئر پارٹس</p>
            <p className="text-gray-600 mt-2">Compatible with DJI Agras, XAG, and other major brands</p>
          </div>
          
          {/* Filters */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="grid md:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Search parts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              >
                {brands.map(brand => (
                  <option key={brand} value={brand}>{brand}</option>
                ))}
              </select>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredParts.map(part => (
              <PartCard key={part.id} part={part} onRequestQuote={handlePartQuote} />
            ))}
          </div>
        </div>
      </section>


      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Success Stories</h2>
            <p className="text-2xl text-gray-600 font-urdu">کامیابی کی کہانیاں</p>
            <p className="text-gray-600 mt-2">Real results from farmers across Pakistan</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {allTestimonials.map(testimonial => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Why Choose AgroSky?</h2>
            <p className="text-2xl text-gray-600 font-urdu">ایگرو اسکائی کیوں منتخب کریں؟</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="text-5xl mb-4">🎯</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Precision Technology</h3>
              <p className="text-gray-600">GPS-guided spraying ensures uniform coverage</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="text-5xl mb-4">💰</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Cost Effective</h3>
              <p className="text-gray-600">Save up to 40% compared to traditional methods</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="text-5xl mb-4">⚡</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Fast Service</h3>
              <p className="text-gray-600">Cover 10 acres per hour with our drones</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="text-5xl mb-4">🛡️</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Genuine Parts</h3>
              <p className="text-gray-600">Authorized dealer for all major brands</p>
            </div>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Service Coverage</h2>
            <p className="text-2xl text-gray-600 font-urdu">خدمات کی کوریج</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-green-600 to-green-700 text-white p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-4">Punjab</h3>
              <ul className="space-y-2">
                <li>✓ Faisalabad</li>
                <li>✓ Multan</li>
                <li>✓ Sahiwal</li>
                <li>✓ Bahawalpur</li>
                <li>✓ All Districts</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-4">Sindh</h3>
              <ul className="space-y-2">
                <li>✓ Hyderabad</li>
                <li>✓ Sukkur</li>
                <li>✓ Larkana</li>
                <li>✓ Mirpurkhas</li>
                <li>✓ Major Districts</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-orange-600 to-orange-700 text-white p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-4">KPK</h3>
              <ul className="space-y-2">
                <li>✓ Peshawar</li>
                <li>✓ Mardan</li>
                <li>✓ Swat</li>
                <li>✓ D.I. Khan</li>
                <li>✓ Selected Areas</li>
              </ul>
            </div>
          </div>
        </div>
      </section>


      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-green-800 mb-3">Get In Touch</h2>
            <p className="text-2xl text-gray-600 font-urdu">رابطہ کریں</p>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="text-3xl mr-4">📞</div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Phone Numbers</h4>
                    <p className="text-gray-600">Punjab: +92 300 1234567</p>
                    <p className="text-gray-600">Sindh: +92 301 7654321</p>
                    <p className="text-gray-600">KPK: +92 302 9876543</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-3xl mr-4">📧</div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Email</h4>
                    <p className="text-gray-600">info@agroskydrones.pk</p>
                    <p className="text-gray-600">parts@agroskydrones.pk</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-3xl mr-4">📍</div>
                  <div>
                    <h4 className="font-semibold text-gray-800">Head Office</h4>
                    <p className="text-gray-600">Main Boulevard, Agricultural Complex</p>
                    <p className="text-gray-600">Faisalabad, Punjab, Pakistan</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="text-3xl mr-4">💬</div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">WhatsApp Support</h4>
                    <button onClick={openWhatsApp} className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition">
                      Chat on WhatsApp
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Quick Inquiry</h3>
              <form onSubmit={(e) => { e.preventDefault(); alert('Thank you! We will contact you soon.'); }}>
                <input type="text" placeholder="Your Name" required className="w-full mb-4 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" />
                <input type="tel" placeholder="Phone Number" required className="w-full mb-4 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" />
                <input type="email" placeholder="Email Address" required className="w-full mb-4 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" />
                <select className="w-full mb-4 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500">
                  <option>Spray Service</option>
                  <option>Spare Parts</option>
                  <option>General Inquiry</option>
                </select>
                <textarea placeholder="Your Message" rows={4} className="w-full mb-4 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"></textarea>
                <button type="submit" className="w-full bg-orange-500 text-white py-3 rounded-lg font-semibold hover:bg-orange-600 transition">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-green-900 to-green-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">AgroSky Drones</h3>
              <p className="text-green-100 mb-2 font-urdu">ایگرو اسکائی ڈرونز</p>
              <p className="text-green-200 text-sm">Pakistan's leading drone agriculture service provider and spare parts supplier.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-green-200 text-sm">
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white transition">Spray Services</button></li>
                <li><button onClick={() => scrollToSection('parts')} className="hover:text-white transition">Spare Parts</button></li>
                <li>Drone Maintenance</li>
                <li>Training Programs</li>
                <li>Consultation</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-green-200 text-sm">
                <li><button onClick={() => scrollToSection('testimonials')} className="hover:text-white transition">Success Stories</button></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-white transition">Contact Us</button></li>
                <li>About Us</li>
                <li>FAQ</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4 mb-4">
                <button className="text-2xl hover:text-orange-400 transition">📘</button>
                <button className="text-2xl hover:text-orange-400 transition">📷</button>
                <button className="text-2xl hover:text-orange-400 transition">🐦</button>
                <button className="text-2xl hover:text-orange-400 transition">▶️</button>
              </div>
              <p className="text-green-200 text-sm">Stay updated with latest agriculture technology and offers</p>
            </div>
          </div>
          <div className="border-t border-green-700 pt-8 text-center">
            <p className="text-green-200 text-sm">&copy; 2025 AgroSky Drones. All rights reserved. | Empowering Pakistani Farmers</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

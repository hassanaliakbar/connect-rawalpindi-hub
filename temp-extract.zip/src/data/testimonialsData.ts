export interface Testimonial {
  id: string;
  name: string;
  nameUrdu: string;
  location: string;
  cropType: string;
  image: string;
  testimonial: string;
  testimonialUrdu: string;
  yieldIncrease: string;
  farmSize: string;
}

export const testimonials: Testimonial[] = [
  {
    id: "1",
    name: "Muhammad Akram",
    nameUrdu: "محمد اکرم",
    location: "Faisalabad, Punjab",
    cropType: "Wheat",
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863957982_9b78edee.webp",
    testimonial: "Drone spraying saved my wheat crop! 30% better yield this season.",
    testimonialUrdu: "ڈرون سپرے نے میری گندم کی فصل بچائی! اس موسم میں 30٪ بہتر پیداوار۔",
    yieldIncrease: "30%",
    farmSize: "25 Acres"
  },
  {
    id: "2",
    name: "Ahmed Hassan",
    nameUrdu: "احمد حسن",
    location: "Multan, Punjab",
    cropType: "Cotton",
    image: "https://d64gsuwffb70l.cloudfront.net/68f4a6864f0e9ffc70354282_1760863961600_0b1fdce7.webp",
    testimonial: "Professional service, affordable prices. My cotton quality improved significantly.",
    testimonialUrdu: "پیشہ ورانہ خدمت، سستی قیمتیں۔ میری کپاس کا معیار نمایاں طور پر بہتر ہوا۔",
    yieldIncrease: "25%",
    farmSize: "40 Acres"
  }
];
